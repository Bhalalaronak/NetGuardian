#!/usr/bin/env python3
"""
NetGuardian - Network Security Analysis Tool
Main application entry point
"""

import sys
import os
import argparse
from PyQt5.QtWidgets import QApplication
from PyQt5.QtCore import Qt
from src.gui.main_window import MainWindow

def parse_arguments():
    """Parse command line arguments"""
    parser = argparse.ArgumentParser(description='NetGuardian - Network Security Analysis Tool')
    parser.add_argument('-i', '--interface', help='Network interface to use')
    parser.add_argument('-r', '--range', help='Network range to scan (CIDR notation)')
    parser.add_argument('-v', '--verbose', action='store_true', help='Enable verbose output')
    parser.add_argument('--no-gui', action='store_true', help='Run in command-line mode (not implemented yet)')
    return parser.parse_args()

def check_privileges():
    """Check if the application has the necessary privileges"""
    if os.name == 'nt':  # Windows
        import ctypes
        return ctypes.windll.shell32.IsUserAnAdmin() != 0
    else:  # Unix/Linux/Mac
        return os.geteuid() == 0

def main():
    """Main application entry point"""
    # Parse command line arguments
    args = parse_arguments()
    
    # Check for admin/root privileges
    if not check_privileges():
        print("Warning: NetGuardian requires administrative privileges for full functionality.")
        print("Some features may not work correctly.")
        print("Please run the application with sudo (Linux/Mac) or as Administrator (Windows).")
        
        # Uncomment to enforce admin privileges
        # print("Exiting. Please restart with appropriate privileges.")
        # sys.exit(1)
    
    # Initialize the GUI application
    QApplication.setAttribute(Qt.AA_EnableHighDpiScaling, True)
    app = QApplication(sys.argv)
    app.setApplicationName("NetGuardian")
    app.setOrganizationName("NetGuardian")
    
    # Create and show the main window
    main_window = MainWindow(args)
    main_window.show()
    
    # Start the application event loop
    sys.exit(app.exec_())

if __name__ == "__main__":
    main()
