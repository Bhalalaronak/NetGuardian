# NetGuardian - Network Security Analysis Tool

![NetGuardian Logo](https://github.com/username/NetGuardian/raw/main/assets/logo.png)

## Overview

NetGuardian is a comprehensive network security analysis tool designed for cybersecurity professionals and students. It provides real-time network monitoring, vulnerability scanning, and traffic analysis through an intuitive graphical user interface.

## Features

- **Real-time Network Discovery**: Automatically detect and map all devices on the network
- **Port Scanning**: Identify open ports and running services on target systems
- **Vulnerability Assessment**: Basic vulnerability detection based on open ports and services
- **Traffic Analysis**: Monitor and analyze network traffic in real-time
- **Packet Capture**: Capture and inspect network packets with detailed protocol information
- **Network Visualization**: Interactive network topology map
- **Alert System**: Configurable alerts for suspicious network activities
- **Reporting**: Generate detailed security reports in multiple formats

## Screenshots

![Dashboard](https://github.com/username/NetGuardian/raw/main/assets/dashboard.png)
![Network Map](https://github.com/username/NetGuardian/raw/main/assets/network_map.png)
![Traffic Analysis](https://github.com/username/NetGuardian/raw/main/assets/traffic_analysis.png)

## Requirements

- Python 3.8+
- Operating System: Linux (recommended), macOS, or Windows with admin privileges
- Network interface with promiscuous mode support
- Required Python packages (see requirements.txt)

## Installation

1. Clone the repository:
```bash
git clone https://github.com/username/NetGuardian.git
cd NetGuardian
```

2. Create and activate a virtual environment (recommended):
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

3. Install required packages:
```bash
pip install -r requirements.txt
```

4. Install system dependencies (Linux):
```bash
sudo apt-get update
sudo apt-get install tcpdump libpcap-dev python3-dev
```

## Usage

1. Start the application with administrative privileges:
```bash
sudo python netguardian.py  # On Windows: Run as Administrator
```

2. Select your network interface from the dropdown menu

3. Configure scan settings:
   - Network range (e.g., 192.168.1.0/24)
   - Scan intensity (affects speed and stealth)
   - Port range to scan

4. Click "Start Scan" to begin network discovery and analysis

5. Use the tabs to navigate between different features:
   - Dashboard: Overview of network status and recent alerts
   - Network Map: Interactive visualization of discovered devices
   - Port Scanner: Detailed port scanning results
   - Traffic Monitor: Real-time traffic analysis
   - Packet Capture: Detailed packet inspection
   - Reports: Generate and view security reports

## Key Components

### Network Discovery Module
- Uses ARP, ICMP, and passive detection techniques
- Identifies device types, operating systems, and hostnames when possible
- Maintains a database of discovered devices

### Port Scanner
- Multi-threaded TCP/UDP port scanner
- Service version detection
- Common vulnerability checking

### Traffic Analyzer
- Real-time bandwidth monitoring
- Protocol distribution analysis
- Connection tracking
- Anomaly detection

### Packet Capture Engine
- Raw packet capture using libpcap
- Protocol decoding and analysis
- Filter-based capture
- Session reconstruction

## Project Structure

```
NetGuardian/
├── netguardian.py           # Main application entry point
├── requirements.txt         # Python dependencies
├── assets/                  # Images and resources
├── docs/                    # Documentation
├── src/
│   ├── gui/                 # GUI components
│   │   ├── __init__.py
│   │   ├── main_window.py
│   │   ├── dashboard.py
│   │   ├── network_map.py
│   │   ├── port_scanner.py
│   │   ├── traffic_monitor.py
│   │   └── packet_capture.py
│   ├── core/                # Core functionality
│   │   ├── __init__.py
│   │   ├── network_discovery.py
│   │   ├── port_scanner.py
│   │   ├── traffic_analyzer.py
│   │   ├── packet_capture.py
│   │   └── vulnerability_checker.py
│   ├── utils/               # Utility functions
│   │   ├── __init__.py
│   │   ├── network_utils.py
│   │   ├── data_storage.py
│   │   └── report_generator.py
│   └── models/              # Data models
│       ├── __init__.py
│       ├── device.py
│       ├── vulnerability.py
│       └── network_traffic.py
└── tests/                   # Unit tests
    ├── __init__.py
    ├── test_discovery.py
    ├── test_scanner.py
    └── test_analyzer.py
```

## Security and Ethics

This tool is designed for educational purposes and legitimate security assessments only. Always:

1. Obtain proper authorization before scanning any network
2. Use only on networks you own or have explicit permission to test
3. Be aware of legal implications of network scanning in your jurisdiction
4. Follow responsible disclosure practices if vulnerabilities are found

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add some amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Acknowledgments

- [Scapy](https://scapy.net/) for packet manipulation
- [PyQt5](https://www.riverbankcomputing.com/software/pyqt/) for the GUI framework
- [Matplotlib](https://matplotlib.org/) for data visualization
- All open-source security tools that inspired this project

## Disclaimer

This software is provided for educational and ethical testing purposes only. Users take full responsibility for how they use this tool and must comply with all applicable laws and regulations.
