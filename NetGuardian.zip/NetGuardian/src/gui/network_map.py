#!/usr/bin/env python3
"""
NetGuardian - Network Map Widget
Provides a visual representation of the network topology
"""

import random
import time
import math
from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, 
                           QFrame, QSplitter, QTableWidget, QTableWidgetItem,
                           QHeaderView, QPushButton, QComboBox)
from PyQt5.QtCore import Qt, QTimer, QRectF, QPointF
from PyQt5.QtGui import QPainter, QColor, QPen, QBrush, QPainterPath

import networkx as nx
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure

class NetworkGraphWidget(QFrame):
    """Widget displaying the network graph visualization"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFrameShape(QFrame.StyledPanel)
        self.setFrameShadow(QFrame.Raised)
        self.setMinimumSize(400, 300)
        
        self.devices = {}  # IP -> device info
        self.connections = []  # (source_ip, target_ip, metadata)
        
        self.layout = QVBoxLayout(self)
        
        # Controls for the graph
        controls_layout = QHBoxLayout()
        
        self.layout_combo = QComboBox()
        self.layout_combo.addItems(["Spring", "Circular", "Shell", "Spectral"])
        self.layout_combo.currentTextChanged.connect(self.update_graph)
        controls_layout.addWidget(QLabel("Layout:"))
        controls_layout.addWidget(self.layout_combo)
        
        self.refresh_button = QPushButton("Refresh")
        self.refresh_button.clicked.connect(self.update_graph)
        controls_layout.addWidget(self.refresh_button)
        
        controls_layout.addStretch()
        self.layout.addLayout(controls_layout)
        
        # Create matplotlib figure for the graph
        self.figure = Figure(figsize=(5, 4), dpi=100)
        self.canvas = FigureCanvas(self.figure)
        self.layout.addWidget(self.canvas)
        
        self.ax = self.figure.add_subplot(111)
        self.initialize_graph()
    
    def initialize_graph(self):
        """Initialize an empty graph"""
        self.ax.clear()
        self.ax.set_title('Network Topology')
        self.ax.axis('off')  # Hide axes
        self.canvas.draw()
    
    def add_device(self, ip, device_type="unknown", hostname="", mac=""):
        """Add a device to the graph"""
        self.devices[ip] = {
            'type': device_type,
            'hostname': hostname,
            'mac': mac,
            'first_seen': time.time(),
            'last_seen': time.time()
        }
    
    def add_connection(self, source_ip, target_ip, protocol="", port=0):
        """Add a connection between devices"""
        if source_ip in self.devices and target_ip in self.devices:
            self.connections.append((source_ip, target_ip, {
                'protocol': protocol,
                'port': port,
                'timestamp': time.time()
            }))
    
    def update_graph(self):
        """Update the network graph visualization"""
        if not self.devices:
            self.initialize_graph()
            return
        
        # Create a networkx graph
        G = nx.Graph()
        
        # Add nodes (devices)
        for ip, device in self.devices.items():
            G.add_node(ip, **device)
        
        # Add edges (connections)
        for source, target, metadata in self.connections:
            G.add_edge(source, target, **metadata)
        
        # Clear the previous plot
        self.ax.clear()
        
        # Choose layout algorithm
        layout_name = self.layout_combo.currentText()
        if layout_name == "Spring":
            pos = nx.spring_layout(G)
        elif layout_name == "Circular":
            pos = nx.circular_layout(G)
        elif layout_name == "Shell":
            pos = nx.shell_layout(G)
        else:  # Spectral
            pos = nx.spectral_layout(G)
        
        # Node colors based on device type
        node_colors = []
        for node in G.nodes():
            device_type = G.nodes[node].get('type', 'unknown')
            if device_type == 'router':
                node_colors.append('red')
            elif device_type == 'switch':
                node_colors.append('green')
            elif device_type == 'server':
                node_colors.append('blue')
            else:
                node_colors.append('gray')
        
        # Draw the network graph
        nx.draw(G, pos, ax=self.ax, with_labels=True, node_color=node_colors, 
               node_size=500, font_size=8, font_weight='bold', 
               edge_color='lightgray', width=1.0, alpha=0.8)
        
        self.ax.set_title('Network Topology')
        self.ax.axis('off')  # Hide axes
        self.canvas.draw()

class DeviceTableWidget(QFrame):
    """Widget displaying the table of discovered devices"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFrameShape(QFrame.StyledPanel)
        self.setFrameShadow(QFrame.Raised)
        
        layout = QVBoxLayout(self)
        
        # Create table
        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels(["IP Address", "MAC Address", "Hostname", "Type", "Status"])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        
        layout.addWidget(self.table)
    
    def add_device(self, ip, mac="", hostname="", device_type="Unknown", status="Online"):
        """Add a device to the table"""
        row = self.table.rowCount()
        self.table.insertRow(row)
        
        self.table.setItem(row, 0, QTableWidgetItem(ip))
        self.table.setItem(row, 1, QTableWidgetItem(mac))
        self.table.setItem(row, 2, QTableWidgetItem(hostname))
        self.table.setItem(row, 3, QTableWidgetItem(device_type))
        
        status_item = QTableWidgetItem(status)
        if status == "Online":
            status_item.setBackground(QColor(200, 255, 200))
        else:
            status_item.setBackground(QColor(255, 200, 200))
        
        self.table.setItem(row, 4, status_item)
    
    def clear_devices(self):
        """Clear all devices from the table"""
        self.table.setRowCount(0)
    
    def get_device_count(self):
        """Get the number of devices in the table"""
        return self.table.rowCount()

class NetworkMapWidget(QWidget):
    """Main network map widget"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        
        self.setup_ui()
        
        # Timer for simulating device discovery
        self.discovery_timer = QTimer(self)
        self.discovery_timer.timeout.connect(self.simulate_discovery)
        
        # Simulated network data
        self.simulated_devices = []
        self.simulated_router = "192.168.1.1"
    
    def setup_ui(self):
        """Set up the user interface"""
        layout = QVBoxLayout(self)
        
        # Create splitter for graph and device table
        splitter = QSplitter(Qt.Vertical)
        
        self.graph_widget = NetworkGraphWidget()
        splitter.addWidget(self.graph_widget)
        
        self.device_table = DeviceTableWidget()
        splitter.addWidget(self.device_table)
        
        # Set the initial sizes of the splitter
        splitter.setSizes([600, 400])
        
        layout.addWidget(splitter)
    
    def start_scan(self, interface, network_range):
        """Start network scanning"""
        # Clear previous data
        self.device_table.clear_devices()
        self.simulated_devices = []
        
        # Add router as the first device
        self.add_simulated_device(
            self.simulated_router, 
            "AA:BB:CC:DD:EE:FF", 
            "Router", 
            "router"
        )
        
        # Start discovery simulation
        self.discovery_timer.start(1000)  # Discover devices every second
    
    def stop_scan(self):
        """Stop network scanning"""
        self.discovery_timer.stop()
    
    def get_device_count(self):
        """Get the number of discovered devices"""
        return self.device_table.get_device_count()
    
    def add_simulated_device(self, ip, mac, hostname, device_type):
        """Add a simulated device to the network map"""
        # Add to device table
        self.device_table.add_device(ip, mac, hostname, device_type)
        
        # Add to graph
        self.graph_widget.add_device(ip, device_type, hostname, mac)
        
        # If not the router, add connection to router
        if ip != self.simulated_router:
            self.graph_widget.add_connection(ip, self.simulated_router)
        
        # Add to our list of simulated devices
        self.simulated_devices.append(ip)
        
        # Update the graph
        self.graph_widget.update_graph()
    
    def simulate_discovery(self):
        """Simulate discovering new devices on the network"""
        # Stop discovering after finding 10 devices
        if len(self.simulated_devices) >= 10:
            self.discovery_timer.stop()
            return
        
        # Randomly decide whether to discover a device
        if random.random() < 0.7:
            # Generate a random IP in the 192.168.1.x range (excluding router)
            while True:
                ip_last_octet = random.randint(2, 254)
                ip = f"192.168.1.{ip_last_octet}"
                if ip not in self.simulated_devices:
                    break
            
            # Generate a random MAC address
            mac_parts = [format(random.randint(0, 255), '02x') for _ in range(6)]
            mac = ":".join(mac_parts).upper()
            
            # Determine device type and hostname
            device_types = ["computer", "phone", "printer", "server", "iot"]
            device_type = random.choice(device_types)
            
            if device_type == "computer":
                hostname = f"PC-{random.randint(1, 999)}"
            elif device_type == "phone":
                hostname = f"Phone-{random.randint(1, 999)}"
            elif device_type == "printer":
                hostname = f"Printer-{random.randint(1, 99)}"
            elif device_type == "server":
                hostname = f"Server-{random.randint(1, 10)}"
            else:  # IoT
                hostname = f"IoT-{random.randint(1, 50)}"
            
            # Add the device
            self.add_simulated_device(ip, mac, hostname, device_type)
