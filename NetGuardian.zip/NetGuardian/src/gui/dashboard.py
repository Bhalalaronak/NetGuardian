#!/usr/bin/env python3
"""
NetGuardian - Dashboard Widget
Provides an overview of network status and security alerts
"""

import time
from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, 
                           QFrame, QGridLayout, QSplitter, QTableWidget,
                           QTableWidgetItem, QHeaderView)
from PyQt5.QtCore import Qt, QTimer, pyqtSignal
from PyQt5.QtGui import QColor, QPalette

import matplotlib.pyplot as plt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure

class NetworkStatsWidget(QFrame):
    """Widget displaying network statistics"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFrameShape(QFrame.StyledPanel)
        self.setFrameShadow(QFrame.Raised)
        
        layout = QVBoxLayout(self)
        
        # Title
        title = QLabel("Network Statistics")
        title.setStyleSheet("font-weight: bold; font-size: 14px;")
        layout.addWidget(title)
        
        # Stats grid
        grid = QGridLayout()
        
        labels = [
            "Active Devices:", "Open Ports:", 
            "Traffic Rate:", "Potential Vulnerabilities:",
            "Scan Duration:", "Last Updated:"
        ]
        
        self.values = []
        
        for i, label in enumerate(labels):
            row = i // 2
            col = (i % 2) * 2
            
            grid.addWidget(QLabel(label), row, col)
            
            value_label = QLabel("0")
            value_label.setStyleSheet("font-weight: bold;")
            grid.addWidget(value_label, row, col + 1)
            self.values.append(value_label)
        
        layout.addLayout(grid)
        layout.addStretch()
    
    def update_stats(self, stats):
        """Update the displayed statistics"""
        if 'devices' in stats:
            self.values[0].setText(str(stats['devices']))
        
        if 'open_ports' in stats:
            self.values[1].setText(str(stats['open_ports']))
        
        if 'traffic_rate' in stats:
            self.values[2].setText(f"{stats['traffic_rate']:.2f} KB/s")
        
        if 'vulnerabilities' in stats:
            self.values[3].setText(str(stats['vulnerabilities']))
        
        if 'duration' in stats:
            self.values[4].setText(f"{stats['duration']:.1f} s")
        
        # Always update the last updated time
        self.values[5].setText(time.strftime("%H:%M:%S"))

class TrafficChartWidget(QFrame):
    """Widget displaying network traffic charts"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFrameShape(QFrame.StyledPanel)
        self.setFrameShadow(QFrame.Raised)
        
        layout = QVBoxLayout(self)
        
        # Title
        title = QLabel("Network Traffic")
        title.setStyleSheet("font-weight: bold; font-size: 14px;")
        layout.addWidget(title)
        
        # Create matplotlib figure and canvas
        self.figure = Figure(figsize=(5, 4), dpi=100)
        self.canvas = FigureCanvas(self.figure)
        layout.addWidget(self.canvas)
        
        # Initialize the plot
        self.ax = self.figure.add_subplot(111)
        self.initialize_plot()
        
        # Data for the plot
        self.times = []
        self.values = []
        self.max_points = 60  # 1 minute of data at 1 second intervals
    
    def initialize_plot(self):
        """Initialize the plot with empty data"""
        self.ax.clear()
        self.ax.set_title('Network Traffic')
        self.ax.set_xlabel('Time')
        self.ax.set_ylabel('Traffic (KB/s)')
        self.ax.grid(True)
        self.line, = self.ax.plot([], [], 'b-')
        self.canvas.draw()
    
    def update_plot(self, value):
        """Update the plot with new data"""
        current_time = time.strftime("%H:%M:%S")
        
        self.times.append(current_time)
        self.values.append(value)
        
        # Keep only the last max_points
        if len(self.times) > self.max_points:
            self.times.pop(0)
            self.values.pop(0)
        
        # Update the plot
        self.ax.clear()
        self.ax.set_title('Network Traffic')
        self.ax.set_xlabel('Time')
        self.ax.set_ylabel('Traffic (KB/s)')
        self.ax.grid(True)
        
        # Only show every nth label to avoid crowding
        n = max(1, len(self.times) // 10)
        self.ax.set_xticks(range(0, len(self.times), n))
        self.ax.set_xticklabels([self.times[i] for i in range(0, len(self.times), n)])
        
        self.ax.plot(range(len(self.times)), self.values, 'b-')
        
        # Adjust y-axis to show a bit more than the max value
        if self.values:
            max_val = max(self.values)
            self.ax.set_ylim(0, max_val * 1.2 + 1)
        
        self.canvas.draw()

class AlertsWidget(QFrame):
    """Widget displaying security alerts"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFrameShape(QFrame.StyledPanel)
        self.setFrameShadow(QFrame.Raised)
        
        layout = QVBoxLayout(self)
        
        # Title
        title = QLabel("Security Alerts")
        title.setStyleSheet("font-weight: bold; font-size: 14px;")
        layout.addWidget(title)
        
        # Alerts table
        self.alerts_table = QTableWidget(0, 4)
        self.alerts_table.setHorizontalHeaderLabels(["Time", "Severity", "Source", "Description"])
        self.alerts_table.horizontalHeader().setSectionResizeMode(3, QHeaderView.Stretch)
        layout.addWidget(self.alerts_table)
    
    def add_alert(self, time_str, severity, source, description):
        """Add a new alert to the table"""
        row = self.alerts_table.rowCount()
        self.alerts_table.insertRow(row)
        
        self.alerts_table.setItem(row, 0, QTableWidgetItem(time_str))
        
        severity_item = QTableWidgetItem(severity)
        if severity == "High":
            severity_item.setBackground(QColor(255, 100, 100))
        elif severity == "Medium":
            severity_item.setBackground(QColor(255, 200, 100))
        else:
            severity_item.setBackground(QColor(255, 255, 100))
        
        self.alerts_table.setItem(row, 1, severity_item)
        self.alerts_table.setItem(row, 2, QTableWidgetItem(source))
        self.alerts_table.setItem(row, 3, QTableWidgetItem(description))

class DashboardWidget(QWidget):
    """Main dashboard widget"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        
        self.start_time = None
        self.setup_ui()
        
        # Timer for updating the dashboard
        self.update_timer = QTimer(self)
        self.update_timer.timeout.connect(self.update_dashboard)
        
        # Simulated data for demo purposes
        self.simulated_traffic = 0
        self.simulated_devices = 0
        self.simulated_ports = 0
        self.simulated_vulns = 0
    
    def setup_ui(self):
        """Set up the user interface"""
        layout = QVBoxLayout(self)
        
        # Create top row with network stats and traffic chart
        top_splitter = QSplitter(Qt.Horizontal)
        
        self.stats_widget = NetworkStatsWidget()
        top_splitter.addWidget(self.stats_widget)
        
        self.chart_widget = TrafficChartWidget()
        top_splitter.addWidget(self.chart_widget)
        
        # Set the initial sizes of the splitter
        top_splitter.setSizes([300, 700])
        
        layout.addWidget(top_splitter, 1)
        
        # Create bottom row with alerts
        self.alerts_widget = AlertsWidget()
        layout.addWidget(self.alerts_widget, 1)
        
        # Add some initial alerts for demonstration
        self.alerts_widget.add_alert(time.strftime("%H:%M:%S"), "Low", "System", "Dashboard initialized")
    
    def start_scan(self, interface, network_range):
        """Start network scanning"""
        self.start_time = time.time()
        self.update_timer.start(1000)  # Update every second
        
        # Add alert
        self.alerts_widget.add_alert(
            time.strftime("%H:%M:%S"), 
            "Low", 
            "Scanner", 
            f"Started scanning {network_range} on interface {interface}"
        )
        
        # Reset simulated data
        self.simulated_traffic = 0
        self.simulated_devices = 0
        self.simulated_ports = 0
        self.simulated_vulns = 0
    
    def stop_scan(self):
        """Stop network scanning"""
        self.update_timer.stop()
        
        # Add alert
        self.alerts_widget.add_alert(
            time.strftime("%H:%M:%S"), 
            "Low", 
            "Scanner", 
            "Scan stopped"
        )
    
    def update_dashboard(self):
        """Update dashboard with new data"""
        if not self.start_time:
            return
        
        # Calculate scan duration
        duration = time.time() - self.start_time
        
        # In a real application, this data would come from actual network monitoring
        # For this demo, we'll simulate some data
        
        # Simulate increasing traffic with some randomness
        import random
        self.simulated_traffic = min(100, self.simulated_traffic + random.uniform(-5, 10))
        if self.simulated_traffic < 0:
            self.simulated_traffic = 0
        
        # Simulate discovering devices
        if duration < 10 and random.random() > 0.7:
            self.simulated_devices += 1
            
            # Add alert for new device
            if random.random() > 0.5:
                ip = f"192.168.1.{random.randint(2, 254)}"
                self.alerts_widget.add_alert(
                    time.strftime("%H:%M:%S"), 
                    "Low", 
                    "Discovery", 
                    f"New device discovered: {ip}"
                )
        
        # Simulate finding open ports
        if duration < 20 and random.random() > 0.8:
            new_ports = random.randint(1, 3)
            self.simulated_ports += new_ports
            
            # Add alert for open ports
            if random.random() > 0.7:
                ip = f"192.168.1.{random.randint(2, 254)}"
                port = random.choice([21, 22, 23, 25, 80, 443, 445, 3389, 8080])
                service = random.choice(["FTP", "SSH", "Telnet", "SMTP", "HTTP", "HTTPS", "SMB", "RDP", "HTTP-ALT"])
                
                severity = "Medium" if port in [21, 23, 445] else "Low"
                
                self.alerts_widget.add_alert(
                    time.strftime("%H:%M:%S"), 
                    severity, 
                    "Port Scanner", 
                    f"Open port {port} ({service}) on {ip}"
                )
        
        # Simulate finding vulnerabilities
        if duration > 15 and random.random() > 0.95:
            self.simulated_vulns += 1
            
            # Add alert for vulnerability
            ip = f"192.168.1.{random.randint(2, 254)}"
            vuln_types = [
                ("High", "Outdated SSH server with known vulnerabilities"),
                ("High", "SMB service vulnerable to EternalBlue (MS17-010)"),
                ("Medium", "Web server disclosing version information"),
                ("Medium", "Outdated SSL/TLS version"),
                ("High", "Default credentials on admin interface")
            ]
            
            severity, description = random.choice(vuln_types)
            
            self.alerts_widget.add_alert(
                time.strftime("%H:%M:%S"), 
                severity, 
                "Vulnerability Scanner", 
                f"{description} on {ip}"
            )
        
        # Update stats widget
        stats = {
            'devices': self.simulated_devices,
            'open_ports': self.simulated_ports,
            'traffic_rate': self.simulated_traffic,
            'vulnerabilities': self.simulated_vulns,
            'duration': duration
        }
        self.stats_widget.update_stats(stats)
        
        # Update traffic chart
        self.chart_widget.update_plot(self.simulated_traffic)
