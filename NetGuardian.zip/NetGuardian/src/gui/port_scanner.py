#!/usr/bin/env python3
"""
NetGuardian - Port Scanner Widget
Provides interface for scanning and displaying open ports on network devices
"""

import random
import time
from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, 
                           QFrame, QSplitter, QTableWidget, QTableWidgetItem,
                           QHeaderView, QPushButton, QComboBox, QLineEdit,
                           QSpinBox, QCheckBox, QGroupBox, QFormLayout)
from PyQt5.QtCore import Qt, QTimer, pyqtSignal, QThread
from PyQt5.QtGui import QColor

class PortScannerSettingsWidget(QFrame):
    """Widget for port scanner settings"""
    
    scan_requested = pyqtSignal(str, str, int, int, bool, bool)
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFrameShape(QFrame.StyledPanel)
        self.setFrameShadow(QFrame.Raised)
        
        self.setup_ui()
    
    def setup_ui(self):
        """Set up the user interface"""
        layout = QVBoxLayout(self)
        
        # Create form layout for settings
        form_layout = QFormLayout()
        
        # Target input
        self.target_input = QLineEdit()
        self.target_input.setPlaceholderText("IP address, hostname, or CIDR range")
        form_layout.addRow("Target:", self.target_input)
        
        # Port range
        port_range_layout = QHBoxLayout()
        
        self.port_start = QSpinBox()
        self.port_start.setRange(1, 65535)
        self.port_start.setValue(1)
        port_range_layout.addWidget(self.port_start)
        
        port_range_layout.addWidget(QLabel("to"))
        
        self.port_end = QSpinBox()
        self.port_end.setRange(1, 65535)
        self.port_end.setValue(1024)
        port_range_layout.addWidget(self.port_end)
        
        # Common port presets
        self.port_preset = QComboBox()
        self.port_preset.addItems(["Custom", "Common (1-1024)", "All (1-65535)", "Web (80, 443, 8080, 8443)"])
        self.port_preset.currentTextChanged.connect(self.on_port_preset_changed)
        port_range_layout.addWidget(self.port_preset)
        
        form_layout.addRow("Port Range:", port_range_layout)
        
        # Scan options
        options_layout = QHBoxLayout()
        
        self.tcp_checkbox = QCheckBox("TCP")
        self.tcp_checkbox.setChecked(True)
        options_layout.addWidget(self.tcp_checkbox)
        
        self.udp_checkbox = QCheckBox("UDP")
        options_layout.addWidget(self.udp_checkbox)
        
        self.service_detection = QCheckBox("Service Detection")
        self.service_detection.setChecked(True)
        options_layout.addWidget(self.service_detection)
        
        form_layout.addRow("Options:", options_layout)
        
        layout.addLayout(form_layout)
        
        # Scan button
        button_layout = QHBoxLayout()
        
        self.scan_button = QPushButton("Start Scan")
        self.scan_button.clicked.connect(self.request_scan)
        button_layout.addWidget(self.scan_button)
        
        self.stop_button = QPushButton("Stop")
        self.stop_button.setEnabled(False)
        button_layout.addWidget(self.stop_button)
        
        layout.addLayout(button_layout)
    
    def on_port_preset_changed(self, preset):
        """Handle port preset selection"""
        if preset == "Common (1-1024)":
            self.port_start.setValue(1)
            self.port_end.setValue(1024)
        elif preset == "All (1-65535)":
            self.port_start.setValue(1)
            self.port_end.setValue(65535)
        elif preset == "Web (80, 443, 8080, 8443)":
            # This would require custom port list support
            # For now, just set a range that includes these ports
            self.port_start.setValue(80)
            self.port_end.setValue(8443)
    
    def request_scan(self):
        """Emit signal to request a port scan"""
        target = self.target_input.text().strip()
        if not target:
            return
        
        port_start = self.port_start.value()
        port_end = self.port_end.value()
        tcp = self.tcp_checkbox.isChecked()
        udp = self.udp_checkbox.isChecked()
        
        self.scan_requested.emit(target, "Custom", port_start, port_end, tcp, udp)
        
        # Update button states
        self.scan_button.setEnabled(False)
        self.stop_button.setEnabled(True)
    
    def scan_finished(self):
        """Handle scan completion"""
        self.scan_button.setEnabled(True)
        self.stop_button.setEnabled(False)

class PortScanResultsWidget(QFrame):
    """Widget displaying port scan results"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFrameShape(QFrame.StyledPanel)
        self.setFrameShadow(QFrame.Raised)
        
        self.setup_ui()
    
    def setup_ui(self):
        """Set up the user interface"""
        layout = QVBoxLayout(self)
        
        # Create table for results
        self.results_table = QTableWidget(0, 6)
        self.results_table.setHorizontalHeaderLabels([
            "IP Address", "Port", "Protocol", "State", "Service", "Version"
        ])
        self.results_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.results_table.setSelectionBehavior(QTableWidget.SelectRows)
        
        layout.addWidget(self.results_table)
        
        # Status label
        self.status_label = QLabel("Ready")
        layout.addWidget(self.status_label)
    
    def add_result(self, ip, port, protocol, state, service="", version=""):
        """Add a scan result to the table"""
        row = self.results_table.rowCount()
        self.results_table.insertRow(row)
        
        self.results_table.setItem(row, 0, QTableWidgetItem(ip))
        self.results_table.setItem(row, 1, QTableWidgetItem(str(port)))
        self.results_table.setItem(row, 2, QTableWidgetItem(protocol))
        
        state_item = QTableWidgetItem(state)
        if state == "Open":
            state_item.setBackground(QColor(200, 255, 200))
        elif state == "Closed":
            state_item.setBackground(QColor(255, 200, 200))
        else:
            state_item.setBackground(QColor(255, 255, 200))
        
        self.results_table.setItem(row, 3, state_item)
        self.results_table.setItem(row, 4, QTableWidgetItem(service))
        self.results_table.setItem(row, 5, QTableWidgetItem(version))
    
    def clear_results(self):
        """Clear all results from the table"""
        self.results_table.setRowCount(0)
        self.status_label.setText("Ready")
    
    def update_status(self, status):
        """Update the status label"""
        self.status_label.setText(status)

class VulnerabilityWidget(QFrame):
    """Widget displaying potential vulnerabilities based on open ports"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFrameShape(QFrame.StyledPanel)
        self.setFrameShadow(QFrame.Raised)
        
        self.setup_ui()
    
    def setup_ui(self):
        """Set up the user interface"""
        layout = QVBoxLayout(self)
        
        # Title
        title = QLabel("Potential Vulnerabilities")
        title.setStyleSheet("font-weight: bold; font-size: 14px;")
        layout.addWidget(title)
        
        # Create table for vulnerabilities
        self.vuln_table = QTableWidget(0, 4)
        self.vuln_table.setHorizontalHeaderLabels([
            "IP Address", "Port/Service", "Severity", "Description"
        ])
        self.vuln_table.horizontalHeader().setSectionResizeMode(3, QHeaderView.Stretch)
        self.vuln_table.setSelectionBehavior(QTableWidget.SelectRows)
        
        layout.addWidget(self.vuln_table)
    
    def add_vulnerability(self, ip, port_service, severity, description):
        """Add a vulnerability to the table"""
        row = self.vuln_table.rowCount()
        self.vuln_table.insertRow(row)
        
        self.vuln_table.setItem(row, 0, QTableWidgetItem(ip))
        self.vuln_table.setItem(row, 1, QTableWidgetItem(port_service))
        
        severity_item = QTableWidgetItem(severity)
        if severity == "High":
            severity_item.setBackground(QColor(255, 150, 150))
        elif severity == "Medium":
            severity_item.setBackground(QColor(255, 200, 150))
        else:
            severity_item.setBackground(QColor(255, 255, 150))
        
        self.vuln_table.setItem(row, 2, severity_item)
        self.vuln_table.setItem(row, 3, QTableWidgetItem(description))
    
    def clear_vulnerabilities(self):
        """Clear all vulnerabilities from the table"""
        self.vuln_table.setRowCount(0)

class PortScannerWidget(QWidget):
    """Main port scanner widget"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        
        self.setup_ui()
        
        # Timer for simulating port scanning
        self.scan_timer = QTimer(self)
        self.scan_timer.timeout.connect(self.simulate_scan_progress)
        
        # Scan state
        self.scanning = False
        self.scan_target = ""
        self.scan_progress = 0
        self.scan_total = 0
        self.discovered_ports = []
    
    def setup_ui(self):
        """Set up the user interface"""
        layout = QVBoxLayout(self)
        
        # Settings section
        self.settings_widget = PortScannerSettingsWidget()
        self.settings_widget.scan_requested.connect(self.start_scan)
        layout.addWidget(self.settings_widget)
        
        # Results section
        results_splitter = QSplitter(Qt.Vertical)
        
        self.results_widget = PortScanResultsWidget()
        results_splitter.addWidget(self.results_widget)
        
        self.vuln_widget = VulnerabilityWidget()
        results_splitter.addWidget(self.vuln_widget)
        
        # Set the initial sizes of the splitter
        results_splitter.setSizes([600, 400])
        
        layout.addWidget(results_splitter)
    
    def start_scan(self, target, scan_type, port_start, port_end, tcp, udp):
        """Start port scanning"""
        if self.scanning:
            return
        
        # Clear previous results
        self.results_widget.clear_results()
        self.vuln_widget.clear_vulnerabilities()
        
        # Set scan parameters
        self.scan_target = target
        self.scan_progress = 0
        self.scan_total = port_end - port_start + 1
        self.discovered_ports = []
        
        # Update status
        self.results_widget.update_status(f"Scanning {target} ports {port_start}-{port_end}...")
        
        # Start scan simulation
        self.scanning = True
        self.scan_timer.start(100)  # Update every 100ms for simulation
    
    def stop_scan(self):
        """Stop port scanning"""
        if not self.scanning:
            return
        
        self.scanning = False
        self.scan_timer.stop()
        
        # Update status
        self.results_widget.update_status("Scan stopped")
        
        # Update settings widget
        self.settings_widget.scan_finished()
    
    def simulate_scan_progress(self):
        """Simulate port scanning progress"""
        if not self.scanning:
            return
        
        # Simulate scanning 10 ports at a time
        self.scan_progress += 10
        
        # Update status
        progress_pct = min(100, int(self.scan_progress / self.scan_total * 100))
        self.results_widget.update_status(
            f"Scanning {self.scan_target}... {progress_pct}% complete"
        )
        
        # Randomly discover open ports
        if random.random() < 0.2:  # 20% chance to find an open port
            # Generate a random port
            port = random.randint(1, 65535)
            
            # Skip if we've already discovered this port
            if port in [p[0] for p in self.discovered_ports]:
                return
            
            # Determine protocol
            protocol = random.choice(["TCP", "UDP"])
            
            # Determine service based on port
            service = ""
            version = ""
            
            if port == 21:
                service = "FTP"
                version = random.choice(["vsftpd 2.3.4", "ProFTPD 1.3.5", "FileZilla Server 0.9.60"])
            elif port == 22:
                service = "SSH"
                version = random.choice(["OpenSSH 7.6p1", "OpenSSH 8.2p1", "Dropbear sshd"])
            elif port == 23:
                service = "Telnet"
                version = random.choice(["Linux telnetd", ""])
            elif port == 25:
                service = "SMTP"
                version = random.choice(["Postfix", "Exim 4.92", "Microsoft ESMTP 6.0.3790.3959"])
            elif port == 80:
                service = "HTTP"
                version = random.choice(["Apache httpd 2.4.29", "nginx 1.18.0", "Microsoft IIS 10.0"])
            elif port == 443:
                service = "HTTPS"
                version = random.choice(["Apache httpd 2.4.29", "nginx 1.18.0", "Microsoft IIS 10.0"])
            elif port == 445:
                service = "SMB"
                version = random.choice(["Samba 4.7.6", "Windows Server 2016 Standard 14393"])
            elif port == 3306:
                service = "MySQL"
                version = random.choice(["MySQL 5.7.33", "MariaDB 10.3.27"])
            elif port == 3389:
                service = "RDP"
                version = random.choice(["Microsoft Terminal Services", "xrdp"])
            elif port == 8080:
                service = "HTTP-Proxy"
                version = random.choice(["Apache Tomcat 9.0.45", "Jetty 9.4.39"])
            else:
                service = random.choice(["Unknown", ""])
            
            # Add the discovered port
            self.discovered_ports.append((port, protocol, service, version))
            
            # Add to results table
            self.results_widget.add_result(
                self.scan_target, port, protocol, "Open", service, version
            )
            
            # Check for potential vulnerabilities
            self.check_for_vulnerabilities(self.scan_target, port, protocol, service, version)
        
        # End scan if we've reached the end
        if self.scan_progress >= self.scan_total:
            self.scanning = False
            self.scan_timer.stop()
            
            # Update status
            self.results_widget.update_status(
                f"Scan complete. Found {len(self.discovered_ports)} open ports."
            )
            
            # Update settings widget
            self.settings_widget.scan_finished()
    
    def check_for_vulnerabilities(self, ip, port, protocol, service, version):
        """Check for potential vulnerabilities based on open ports and services"""
        # This is a simplified simulation - in a real tool, this would use
        # vulnerability databases and more sophisticated detection methods
        
        if service == "FTP" and "vsftpd 2.3.4" in version:
            self.vuln_widget.add_vulnerability(
                ip, f"{port}/{service}", "High",
                "vsftpd 2.3.4 backdoor vulnerability (CVE-2011-2523)"
            )
        
        elif service == "SSH" and "7.6" in version:
            self.vuln_widget.add_vulnerability(
                ip, f"{port}/{service}", "Medium",
                "OpenSSH 7.6p1 is vulnerable to user enumeration (CVE-2018-15473)"
            )
        
        elif service == "Telnet":
            self.vuln_widget.add_vulnerability(
                ip, f"{port}/{service}", "High",
                "Telnet sends data in cleartext and is vulnerable to eavesdropping"
            )
        
        elif service == "SMB" and "4.7.6" in version:
            self.vuln_widget.add_vulnerability(
                ip, f"{port}/{service}", "High",
                "Samba 4.7.6 remote code execution vulnerability (CVE-2018-1057)"
            )
        
        elif service == "HTTP" and port == 80:
            if random.random() < 0.5:
                self.vuln_widget.add_vulnerability(
                    ip, f"{port}/{service}", "Medium",
                    "Web server is not using HTTPS encryption"
                )
        
        elif service == "RDP":
            if random.random() < 0.3:
                self.vuln_widget.add_vulnerability(
                    ip, f"{port}/{service}", "High",
                    "RDP BlueKeep vulnerability (CVE-2019-0708)"
                )
        
        # Random generic vulnerabilities
        if random.random() < 0.1:
            generic_vulns = [
                ("Low", "Service banner reveals version information"),
                ("Medium", "Service may be using default credentials"),
                ("High", "Service has known buffer overflow vulnerability")
            ]
            severity, desc = random.choice(generic_vulns)
            self.vuln_widget.add_vulnerability(ip, f"{port}/{service}", severity, desc)
