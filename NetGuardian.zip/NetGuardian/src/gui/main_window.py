#!/usr/bin/env python3
"""
NetGuardian - Main Window
The primary GUI container for the application
"""

import os
import sys
import netifaces
from PyQt5.QtWidgets import (QMainWindow, QTabWidget, QComboBox, 
                            QLabel, QPushButton, QVBoxLayout, QHBoxLayout, 
                            QWidget, QStatusBar, QAction, QToolBar, 
                            QLineEdit, QMessageBox, QFrame, QSplitter)
from PyQt5.QtCore import Qt, QSize, QTimer, pyqtSlot
from PyQt5.QtGui import QIcon, QPixmap

from .dashboard import DashboardWidget
from .network_map import NetworkMapWidget
from .port_scanner import PortScannerWidget
from .traffic_monitor import TrafficMonitorWidget
from .packet_capture import PacketCaptureWidget

from ..core.network_discovery import NetworkDiscovery

class MainWindow(QMainWindow):
    """Main application window"""
    
    def __init__(self, args=None):
        super().__init__()
        
        self.args = args
        self.network_discovery = NetworkDiscovery()
        self.active_scan = False
        self.selected_interface = None
        
        self.init_ui()
        self.setup_connections()
        
        # Start with interface selection if provided via args
        if args and args.interface:
            index = self.interface_combo.findText(args.interface)
            if index >= 0:
                self.interface_combo.setCurrentIndex(index)
                self.on_interface_selected(args.interface)
        
        # Start timer for periodic UI updates
        self.update_timer = QTimer(self)
        self.update_timer.timeout.connect(self.update_status)
        self.update_timer.start(1000)  # Update every second
    
    def init_ui(self):
        """Initialize the user interface"""
        # Set window properties
        self.setWindowTitle("NetGuardian - Network Security Analysis Tool")
        self.setMinimumSize(1024, 768)
        
        # Create central widget and main layout
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)
        
        # Create toolbar for common actions
        self.create_toolbar()
        
        # Create interface selection area
        interface_layout = QHBoxLayout()
        interface_layout.addWidget(QLabel("Network Interface:"))
        
        self.interface_combo = QComboBox()
        self.populate_interfaces()
        interface_layout.addWidget(self.interface_combo)
        
        self.scan_button = QPushButton("Start Scan")
        interface_layout.addWidget(self.scan_button)
        
        interface_layout.addWidget(QLabel("Network Range:"))
        self.network_range = QLineEdit("192.168.1.0/24")
        interface_layout.addWidget(self.network_range)
        
        interface_layout.addStretch()
        main_layout.addLayout(interface_layout)
        
        # Create tab widget for main content
        self.tabs = QTabWidget()
        
        # Create and add tabs
        self.dashboard_tab = DashboardWidget()
        self.network_map_tab = NetworkMapWidget()
        self.port_scanner_tab = PortScannerWidget()
        self.traffic_monitor_tab = TrafficMonitorWidget()
        self.packet_capture_tab = PacketCaptureWidget()
        
        self.tabs.addTab(self.dashboard_tab, "Dashboard")
        self.tabs.addTab(self.network_map_tab, "Network Map")
        self.tabs.addTab(self.port_scanner_tab, "Port Scanner")
        self.tabs.addTab(self.traffic_monitor_tab, "Traffic Monitor")
        self.tabs.addTab(self.packet_capture_tab, "Packet Capture")
        
        main_layout.addWidget(self.tabs)
        
        # Create status bar
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)
        
        self.status_interface = QLabel("No interface selected")
        self.status_devices = QLabel("Devices: 0")
        self.status_scan = QLabel("Scan: Inactive")
        
        self.status_bar.addPermanentWidget(self.status_interface)
        self.status_bar.addPermanentWidget(self.status_devices)
        self.status_bar.addPermanentWidget(self.status_scan)
        
        self.status_bar.showMessage("Ready")
    
    def create_toolbar(self):
        """Create the main toolbar"""
        toolbar = QToolBar("Main Toolbar")
        toolbar.setIconSize(QSize(24, 24))
        self.addToolBar(toolbar)
        
        # Add actions
        scan_action = QAction("New Scan", self)
        scan_action.triggered.connect(self.start_scan)
        toolbar.addAction(scan_action)
        
        stop_action = QAction("Stop", self)
        stop_action.triggered.connect(self.stop_scan)
        toolbar.addAction(stop_action)
        
        toolbar.addSeparator()
        
        report_action = QAction("Generate Report", self)
        report_action.triggered.connect(self.generate_report)
        toolbar.addAction(report_action)
        
        toolbar.addSeparator()
        
        settings_action = QAction("Settings", self)
        settings_action.triggered.connect(self.show_settings)
        toolbar.addAction(settings_action)
        
        help_action = QAction("Help", self)
        help_action.triggered.connect(self.show_help)
        toolbar.addAction(help_action)
    
    def populate_interfaces(self):
        """Populate the network interfaces dropdown"""
        self.interface_combo.clear()
        
        try:
            interfaces = netifaces.interfaces()
            for iface in interfaces:
                # Skip loopback interface on non-Windows systems
                if iface == "lo" and os.name != "nt":
                    continue
                
                # Add interface to dropdown
                self.interface_combo.addItem(iface)
        except Exception as e:
            self.status_bar.showMessage(f"Error loading network interfaces: {str(e)}")
    
    def setup_connections(self):
        """Set up signal-slot connections"""
        self.interface_combo.currentTextChanged.connect(self.on_interface_selected)
        self.scan_button.clicked.connect(self.toggle_scan)
    
    def on_interface_selected(self, interface_name):
        """Handle interface selection"""
        self.selected_interface = interface_name
        self.status_interface.setText(f"Interface: {interface_name}")
        
        # Update network range based on selected interface
        try:
            if interface_name and interface_name != "lo":
                addrs = netifaces.ifaddresses(interface_name)
                if netifaces.AF_INET in addrs:
                    ip = addrs[netifaces.AF_INET][0]['addr']
                    # Simple way to get network range - assumes /24
                    network = '.'.join(ip.split('.')[:3]) + '.0/24'
                    self.network_range.setText(network)
        except Exception as e:
            self.status_bar.showMessage(f"Error determining network range: {str(e)}")
    
    def toggle_scan(self):
        """Toggle scan start/stop"""
        if self.active_scan:
            self.stop_scan()
        else:
            self.start_scan()
    
    def start_scan(self):
        """Start network scanning"""
        if not self.selected_interface:
            QMessageBox.warning(self, "No Interface Selected", 
                              "Please select a network interface before starting a scan.")
            return
        
        network_range = self.network_range.text().strip()
        if not network_range:
            QMessageBox.warning(self, "Invalid Network Range", 
                              "Please enter a valid network range (e.g., 192.168.1.0/24).")
            return
        
        # Update UI
        self.scan_button.setText("Stop Scan")
        self.status_scan.setText("Scan: Active")
        self.active_scan = True
        self.status_bar.showMessage("Scanning network...")
        
        # Start scanning in the tabs
        self.dashboard_tab.start_scan(self.selected_interface, network_range)
        self.network_map_tab.start_scan(self.selected_interface, network_range)
        self.port_scanner_tab.start_scan(self.selected_interface, network_range)
        self.traffic_monitor_tab.start_monitoring(self.selected_interface)
        self.packet_capture_tab.start_capture(self.selected_interface)
    
    def stop_scan(self):
        """Stop network scanning"""
        # Update UI
        self.scan_button.setText("Start Scan")
        self.status_scan.setText("Scan: Inactive")
        self.active_scan = False
        self.status_bar.showMessage("Scan stopped")
        
        # Stop scanning in the tabs
        self.dashboard_tab.stop_scan()
        self.network_map_tab.stop_scan()
        self.port_scanner_tab.stop_scan()
        self.traffic_monitor_tab.stop_monitoring()
        self.packet_capture_tab.stop_capture()
    
    def update_status(self):
        """Update status information periodically"""
        if self.active_scan:
            # Update device count
            device_count = self.network_map_tab.get_device_count()
            self.status_devices.setText(f"Devices: {device_count}")
    
    def generate_report(self):
        """Generate a security report"""
        QMessageBox.information(self, "Generate Report", 
                              "Report generation will be implemented in a future version.")
    
    def show_settings(self):
        """Show settings dialog"""
        QMessageBox.information(self, "Settings", 
                              "Settings dialog will be implemented in a future version.")
    
    def show_help(self):
        """Show help information"""
        QMessageBox.information(self, "Help", 
                              "NetGuardian - Network Security Analysis Tool\n\n"
                              "1. Select a network interface\n"
                              "2. Enter a network range to scan\n"
                              "3. Click 'Start Scan' to begin analysis\n"
                              "4. Use the tabs to view different aspects of the network\n\n"
                              "For more information, see the documentation.")
    
    def closeEvent(self, event):
        """Handle window close event"""
        if self.active_scan:
            self.stop_scan()
        event.accept()
