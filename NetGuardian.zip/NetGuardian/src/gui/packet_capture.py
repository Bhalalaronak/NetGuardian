#!/usr/bin/env python3
"""
NetGuardian - Packet Capture Widget
Provides packet capture and analysis functionality
"""

import random
import time
from datetime import datetime
from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, 
                           QFrame, QSplitter, QTableWidget, QTableWidgetItem,
                           QHeaderView, QPushButton, QComboBox, QLineEdit,
                           QGroupBox, QFormLayout, QTextEdit, QCheckBox)
from PyQt5.QtCore import Qt, QTimer, pyqtSignal
from PyQt5.QtGui import QColor, QTextCursor

class CaptureControlWidget(QFrame):
    """Widget for controlling packet capture"""
    
    capture_started = pyqtSignal(str, str)
    capture_stopped = pyqtSignal()
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFrameShape(QFrame.StyledPanel)
        self.setFrameShadow(QFrame.Raised)
        
        self.setup_ui()
    
    def setup_ui(self):
        """Set up the user interface"""
        layout = QVBoxLayout(self)
        
        # Create form layout for settings
        form_layout = QFormLayout()
        
        # Filter input
        self.filter_input = QLineEdit()
        self.filter_input.setPlaceholderText("e.g., tcp port 80 or icmp")
        form_layout.addRow("Capture Filter:", self.filter_input)
        
        # Capture options
        options_group = QGroupBox("Capture Options")
        options_layout = QVBoxLayout()
        
        self.promiscuous_mode = QCheckBox("Promiscuous Mode")
        self.promiscuous_mode.setChecked(True)
        options_layout.addWidget(self.promiscuous_mode)
        
        self.resolve_names = QCheckBox("Resolve Names")
        self.resolve_names.setChecked(True)
        options_layout.addWidget(self.resolve_names)
        
        self.capture_payload = QCheckBox("Capture Payload")
        self.capture_payload.setChecked(True)
        options_layout.addWidget(self.capture_payload)
        
        options_group.setLayout(options_layout)
        form_layout.addRow("", options_group)
        
        layout.addLayout(form_layout)
        
        # Buttons
        button_layout = QHBoxLayout()
        
        self.start_button = QPushButton("Start Capture")
        self.start_button.clicked.connect(self.start_capture)
        button_layout.addWidget(self.start_button)
        
        self.stop_button = QPushButton("Stop Capture")
        self.stop_button.setEnabled(False)
        self.stop_button.clicked.connect(self.stop_capture)
        button_layout.addWidget(self.stop_button)
        
        self.clear_button = QPushButton("Clear")
        self.clear_button.clicked.connect(self.clear_capture)
        button_layout.addWidget(self.clear_button)
        
        layout.addLayout(button_layout)
        
        # Status
        self.status_label = QLabel("Ready")
        layout.addWidget(self.status_label)
    
    def start_capture(self):
        """Start packet capture"""
        filter_text = self.filter_input.text().strip()
        
        # Update UI
        self.start_button.setEnabled(False)
        self.stop_button.setEnabled(True)
        self.status_label.setText("Capturing packets...")
        
        # Emit signal to start capture
        self.capture_started.emit(filter_text, "options")
    
    def stop_capture(self):
        """Stop packet capture"""
        # Update UI
        self.start_button.setEnabled(True)
        self.stop_button.setEnabled(False)
        self.status_label.setText("Capture stopped")
        
        # Emit signal to stop capture
        self.capture_stopped.emit()
    
    def clear_capture(self):
        """Clear captured packets"""
        # Emit signal to clear packets
        self.capture_stopped.emit()
        
        # Update status
        self.status_label.setText("Capture cleared")

class PacketListWidget(QFrame):
    """Widget displaying the list of captured packets"""
    
    packet_selected = pyqtSignal(int)
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFrameShape(QFrame.StyledPanel)
        self.setFrameShadow(QFrame.Raised)
        
        self.setup_ui()
    
    def setup_ui(self):
        """Set up the user interface"""
        layout = QVBoxLayout(self)
        
        # Create table for packets
        self.packet_table = QTableWidget(0, 7)
        self.packet_table.setHorizontalHeaderLabels([
            "No.", "Time", "Source", "Destination", "Protocol", "Length", "Info"
        ])
        self.packet_table.horizontalHeader().setSectionResizeMode(6, QHeaderView.Stretch)
        self.packet_table.setSelectionBehavior(QTableWidget.SelectRows)
        self.packet_table.setSelectionMode(QTableWidget.SingleSelection)
        self.packet_table.itemSelectionChanged.connect(self.on_packet_selected)
        
        layout.addWidget(self.packet_table)
    
    def add_packet(self, packet_num, timestamp, src, dst, protocol, length, info):
        """Add a packet to the table"""
        row = self.packet_table.rowCount()
        self.packet_table.insertRow(row)
        
        self.packet_table.setItem(row, 0, QTableWidgetItem(str(packet_num)))
        self.packet_table.setItem(row, 1, QTableWidgetItem(timestamp))
        self.packet_table.setItem(row, 2, QTableWidgetItem(src))
        self.packet_table.setItem(row, 3, QTableWidgetItem(dst))
        
        protocol_item = QTableWidgetItem(protocol)
        if protocol == "TCP":
            protocol_item.setBackground(QColor(200, 230, 255))
        elif protocol == "UDP":
            protocol_item.setBackground(QColor(230, 255, 200))
        elif protocol == "ICMP":
            protocol_item.setBackground(QColor(255, 230, 200))
        elif protocol == "HTTP":
            protocol_item.setBackground(QColor(255, 200, 255))
        elif protocol == "HTTPS":
            protocol_item.setBackground(QColor(200, 255, 255))
        
        self.packet_table.setItem(row, 4, protocol_item)
        self.packet_table.setItem(row, 5, QTableWidgetItem(str(length)))
        self.packet_table.setItem(row, 6, QTableWidgetItem(info))
        
        # Scroll to the new packet
        self.packet_table.scrollToItem(self.packet_table.item(row, 0))
    
    def clear_packets(self):
        """Clear all packets from the table"""
        self.packet_table.setRowCount(0)
    
    def on_packet_selected(self):
        """Handle packet selection"""
        selected_items = self.packet_table.selectedItems()
        if selected_items:
            row = selected_items[0].row()
            packet_num = int(self.packet_table.item(row, 0).text())
            self.packet_selected.emit(packet_num)

class PacketDetailWidget(QFrame):
    """Widget displaying detailed information about a selected packet"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFrameShape(QFrame.StyledPanel)
        self.setFrameShadow(QFrame.Raised)
        
        self.setup_ui()
    
    def setup_ui(self):
        """Set up the user interface"""
        layout = QVBoxLayout(self)
        
        # Create text area for packet details
        self.details_text = QTextEdit()
        self.details_text.setReadOnly(True)
        self.details_text.setLineWrapMode(QTextEdit.NoWrap)
        self.details_text.setFont(QFont("Courier New", 10))
        
        layout.addWidget(self.details_text)
    
    def show_packet_details(self, packet_data):
        """Show detailed information about a packet"""
        self.details_text.clear()
        self.details_text.insertPlainText(packet_data)
        self.details_text.moveCursor(QTextCursor.Start)

class HexDumpWidget(QFrame):
    """Widget displaying hex dump of packet data"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFrameShape(QFrame.StyledPanel)
        self.setFrameShadow(QFrame.Raised)
        
        self.setup_ui()
    
    def setup_ui(self):
        """Set up the user interface"""
        layout = QVBoxLayout(self)
        
        # Create text area for hex dump
        self.hex_text = QTextEdit()
        self.hex_text.setReadOnly(True)
        self.hex_text.setLineWrapMode(QTextEdit.NoWrap)
        self.hex_text.setFont(QFont("Courier New", 10))
        
        layout.addWidget(self.hex_text)
    
    def show_hex_dump(self, packet_data):
        """Show hex dump of packet data"""
        self.hex_text.clear()
        self.hex_text.insertPlainText(packet_data)
        self.hex_text.moveCursor(QTextCursor.Start)

class PacketCaptureWidget(QWidget):
    """Main packet capture widget"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        
        self.setup_ui()
        
        # Connect signals
        self.control_widget.capture_started.connect(self.start_capture)
        self.control_widget.capture_stopped.connect(self.stop_capture)
        self.packet_list.packet_selected.connect(self.show_packet_details)
        
        # Timer for simulating packet capture
        self.capture_timer = QTimer(self)
        self.capture_timer.timeout.connect(self.simulate_packet_capture)
        
        # Packet storage
        self.packets = []
        self.packet_count = 0
        self.capturing = False
    
    def setup_ui(self):
        """Set up the user interface"""
        layout = QVBoxLayout(self)
        
        # Control section
        self.control_widget = CaptureControlWidget()
        layout.addWidget(self.control_widget)
        
        # Packet list
        self.packet_list = PacketListWidget()
        layout.addWidget(self.packet_list, 1)
        
        # Details section
        details_splitter = QSplitter(Qt.Horizontal)
        
        self.packet_details = PacketDetailWidget()
        details_splitter.addWidget(self.packet_details)
        
        self.hex_dump = HexDumpWidget()
        details_splitter.addWidget(self.hex_dump)
        
        # Set the initial sizes of the splitter
        details_splitter.setSizes([500, 500])
        
        layout.addWidget(details_splitter, 1)
    
    def start_capture(self, filter_text, options):
        """Start packet capture"""
        # Clear previous packets
        self.packet_list.clear_packets()
        self.packets = []
        self.packet_count = 0
        
        # Start capture simulation
        self.capturing = True
        self.capture_timer.start(random.randint(200, 1000))  # Random interval between packets
    
    def stop_capture(self):
        """Stop packet capture"""
        self.capturing = False
        self.capture_timer.stop()
    
    def simulate_packet_capture(self):
        """Simulate capturing a packet"""
        if not self.capturing:
            return
        
        # Generate a simulated packet
        self.packet_count += 1
        timestamp = datetime.now().strftime("%H:%M:%S.%f")[:-3]
        
        # Random source and destination IPs
        src_ip = ".".join([str(random.randint(1, 255)) for _ in range(4)])
        dst_ip = ".".join([str(random.randint(1, 255)) for _ in range(4)])
        
        # Random protocol
        protocol = random.choice(["TCP", "UDP", "ICMP", "HTTP", "HTTPS", "DNS"])
        
        # Random packet length
        length = random.randint(64, 1500)
        
        # Generate info based on protocol
        if protocol == "TCP":
            src_port = random.randint(1024, 65535)
            dst_port = random.choice([80, 443, 22, 25, 8080])
            flags = random.choice(["[SYN]", "[ACK]", "[SYN, ACK]", "[FIN, ACK]", "[PSH, ACK]"])
            info = f"{src_port} → {dst_port} {flags} Seq=0 Win=64240 Len={length-40}"
        elif protocol == "UDP":
            src_port = random.randint(1024, 65535)
            dst_port = random.choice([53, 123, 161, 5353])
            info = f"{src_port} → {dst_port} Len={length-28}"
        elif protocol == "ICMP":
            icmp_type = random.choice(["Echo (ping) request", "Echo (ping) reply"])
            info = f"{icmp_type} id=0x{random.randint(0, 65535):04x} seq={random.randint(1, 100)}"
        elif protocol == "HTTP":
            method = random.choice(["GET", "POST", "PUT", "DELETE"])
            paths = ["/", "/index.html", "/api/data", "/login", "/images/logo.png"]
            path = random.choice(paths)
            info = f"{method} {path} HTTP/1.1"
        elif protocol == "HTTPS":
            info = f"TLSv1.2 Application Data"
        else:  # DNS
            query_types = ["A", "AAAA", "MX", "NS", "TXT"]
            domains = ["example.com", "google.com", "github.com", "aws.amazon.com"]
            info = f"Standard query 0x{random.randint(0, 65535):04x} {random.choice(query_types)} {random.choice(domains)}"
        
        # Add packet to list
        self.packet_list.add_packet(self.packet_count, timestamp, src_ip, dst_ip, protocol, length, info)
        
        # Store packet data
        packet_data = {
            'num': self.packet_count,
            'timestamp': timestamp,
            'src': src_ip,
            'dst': dst_ip,
            'protocol': protocol,
            'length': length,
            'info': info,
            'details': self.generate_packet_details(protocol, src_ip, dst_ip, length, info),
            'hex_dump': self.generate_hex_dump(length)
        }
        self.packets.append(packet_data)
        
        # Set next packet interval
        self.capture_timer.setInterval(random.randint(200, 1000))
    
    def show_packet_details(self, packet_num):
        """Show details for the selected packet"""
        # Find the packet in our storage
        for packet in self.packets:
            if packet['num'] == packet_num:
                self.packet_details.show_packet_details(packet['details'])
                self.hex_dump.show_hex_dump(packet['hex_dump'])
                break
    
    def generate_packet_details(self, protocol, src_ip, dst_ip, length, info):
        """Generate detailed packet information"""
        details = f"Frame {self.packet_count}: {length} bytes on wire\n"
        details += "Ethernet II, Src: 00:11:22:33:44:55, Dst: 66:77:88:99:aa:bb\n"
        
        if protocol in ["TCP", "UDP", "HTTP", "HTTPS"]:
            details += f"Internet Protocol Version 4, Src: {src_ip}, Dst: {dst_ip}\n"
            details += "    Version: 4\n"
            details += "    Header Length: 20 bytes\n"
            details += f"    Total Length: {length}\n"
            details += "    Identification: 0x1234\n"
            details += "    Flags: 0x02 (Don't Fragment)\n"
            details += "    Fragment offset: 0\n"
            details += "    Time to live: 64\n"
            
            if protocol in ["TCP", "HTTP", "HTTPS"]:
                details += "    Protocol: TCP (6)\n"
                details += "    Header checksum: 0x1234\n"
                details += f"    Source: {src_ip}\n"
                details += f"    Destination: {dst_ip}\n\n"
                
                src_port, dst_port = info.split(" → ")[0], info.split(" → ")[1].split(" ")[0]
                
                details += f"Transmission Control Protocol, Src Port: {src_port}, Dst Port: {dst_port}\n"
                details += f"    Source Port: {src_port}\n"
                details += f"    Destination Port: {dst_port}\n"
                details += "    Sequence number: 0\n"
                details += "    Acknowledgment number: 0\n"
                details += "    Header Length: 20 bytes\n"
                
                if "[SYN]" in info:
                    details += "    Flags: 0x002 (SYN)\n"
                elif "[ACK]" in info:
                    details += "    Flags: 0x010 (ACK)\n"
                elif "[SYN, ACK]" in info:
                    details += "    Flags: 0x012 (SYN, ACK)\n"
                elif "[FIN, ACK]" in info:
                    details += "    Flags: 0x011 (FIN, ACK)\n"
                elif "[PSH, ACK]" in info:
                    details += "    Flags: 0x018 (PSH, ACK)\n"
                
                details += "    Window size value: 64240\n"
                details += "    Checksum: 0x1234\n"
                
                if protocol == "HTTP":
                    details += "\nHypertext Transfer Protocol\n"
                    if "GET" in info:
                        path = info.split(" ")[1]
                        details += f"    GET {path} HTTP/1.1\n"
                        details += "    Host: example.com\n"
                        details += "    User-Agent: Mozilla/5.0\n"
                        details += "    Accept: text/html,application/xhtml+xml\n"
                    elif "POST" in info:
                        path = info.split(" ")[1]
                        details += f"    POST {path} HTTP/1.1\n"
                        details += "    Host: example.com\n"
                        details += "    Content-Type: application/x-www-form-urlencoded\n"
                        details += "    Content-Length: 27\n\n"
                        details += "    username=admin&password=secret\n"
                
                elif protocol == "HTTPS":
                    details += "\nTransport Layer Security\n"
                    details += "    TLSv1.2 Record Layer: Application Data Protocol\n"
                    details += "    Content Type: Application Data (23)\n"
                    details += "    Version: TLS 1.2 (0x0303)\n"
                    details += f"    Length: {length - 40 - 5}\n"
                    details += "    Encrypted Application Data\n"
            
            elif protocol == "UDP":
                details += "    Protocol: UDP (17)\n"
                details += "    Header checksum: 0x1234\n"
                details += f"    Source: {src_ip}\n"
                details += f"    Destination: {dst_ip}\n\n"
                
                src_port, dst_port = info.split(" → ")[0], info.split(" → ")[1].split(" ")[0]
                
                details += f"User Datagram Protocol, Src Port: {src_port}, Dst Port: {dst_port}\n"
                details += f"    Source Port: {src_port}\n"
                details += f"    Destination Port: {dst_port}\n"
                details += f"    Length: {length - 20}\n"
                details += "    Checksum: 0x1234\n"
                
                if dst_port == "53":
                    details += "\nDomain Name System (query)\n"
                    details += "    Transaction ID: 0x1234\n"
                    details += "    Flags: 0x0100 Standard query\n"
                    details += "    Questions: 1\n"
                    details += "    Answer RRs: 0\n"
                    details += "    Authority RRs: 0\n"
                    details += "    Additional RRs: 0\n"
                    details += "    Queries\n"
                    details += "        example.com: type A, class IN\n"
        
        elif protocol == "ICMP":
            details += f"Internet Protocol Version 4, Src: {src_ip}, Dst: {dst_ip}\n"
            details += "    Version: 4\n"
            details += "    Header Length: 20 bytes\n"
            details += f"    Total Length: {length}\n"
            details += "    Identification: 0x1234\n"
            details += "    Flags: 0x02 (Don't Fragment)\n"
            details += "    Fragment offset: 0\n"
            details += "    Time to live: 64\n"
            details += "    Protocol: ICMP (1)\n"
            details += "    Header checksum: 0x1234\n"
            details += f"    Source: {src_ip}\n"
            details += f"    Destination: {dst_ip}\n\n"
            
            if "request" in info:
                details += "Internet Control Message Protocol\n"
                details += "    Type: 8 (Echo (ping) request)\n"
                details += "    Code: 0\n"
                details += "    Checksum: 0x1234\n"
                details += f"    Identifier: {info.split('id=')[1].split(' ')[0]}\n"
                details += f"    Sequence number: {info.split('seq=')[1]}\n"
                details += "    Data (32 bytes)\n"
            else:
                details += "Internet Control Message Protocol\n"
                details += "    Type: 0 (Echo (ping) reply)\n"
                details += "    Code: 0\n"
                details += "    Checksum: 0x1234\n"
                details += f"    Identifier: {info.split('id=')[1].split(' ')[0]}\n"
                details += f"    Sequence number: {info.split('seq=')[1]}\n"
                details += "    Data (32 bytes)\n"
        
        return details
    
    def generate_hex_dump(self, length):
        """Generate a hex dump for packet data"""
        hex_dump = ""
        bytes_per_line = 16
        
        # Generate random bytes for the packet
        packet_bytes = [random.randint(0, 255) for _ in range(length)]
        
        for i in range(0, length, bytes_per_line):
            # Offset
            hex_dump += f"{i:04x}  "
            
            # Hex values
            line_bytes = packet_bytes[i:i+bytes_per_line]
            hex_values = " ".join(f"{b:02x}" for b in line_bytes)
            
            # Pad hex values to align ASCII representation
            padding = "   " * (bytes_per_line - len(line_bytes))
            
            # ASCII representation
            ascii_values = "".join(chr(b) if 32 <= b <= 126 else "." for b in line_bytes)
            
            hex_dump += f"{hex_values}{padding}  |{ascii_values}|\n"
        
        return hex_dump

from PyQt5.QtGui import QFont
