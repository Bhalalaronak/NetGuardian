#!/usr/bin/env python3
"""
NetGuardian - Traffic Monitor Widget
Provides real-time monitoring and analysis of network traffic
"""

import random
import time
from collections import deque
from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, 
                           QFrame, QSplitter, QTableWidget, QTableWidgetItem,
                           QHeaderView, QPushButton, QComboBox, QGroupBox)
from PyQt5.QtCore import Qt, QTimer, pyqtSignal
from PyQt5.QtGui import QColor

import matplotlib.pyplot as plt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
import matplotlib.dates as mdates
import numpy as np
from datetime import datetime, timedelta

class TrafficGraphWidget(QFrame):
    """Widget displaying network traffic graphs"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFrameShape(QFrame.StyledPanel)
        self.setFrameShadow(QFrame.Raised)
        
        self.setup_ui()
        
        # Data for the graphs
        self.timestamps = deque(maxlen=60)  # Store last 60 seconds
        self.inbound_data = deque(maxlen=60)
        self.outbound_data = deque(maxlen=60)
        self.total_data = deque(maxlen=60)
        
        # Initialize with zeros
        current_time = datetime.now()
        for i in range(60):
            self.timestamps.append(current_time - timedelta(seconds=60-i))
            self.inbound_data.append(0)
            self.outbound_data.append(0)
            self.total_data.append(0)
    
    def setup_ui(self):
        """Set up the user interface"""
        layout = QVBoxLayout(self)
        
        # Graph type selector
        selector_layout = QHBoxLayout()
        
        selector_layout.addWidget(QLabel("Graph Type:"))
        
        self.graph_type = QComboBox()
        self.graph_type.addItems(["Bandwidth Usage", "Protocol Distribution", "Connection Count"])
        self.graph_type.currentTextChanged.connect(self.update_graph)
        selector_layout.addWidget(self.graph_type)
        
        selector_layout.addStretch()
        
        # Time range selector
        selector_layout.addWidget(QLabel("Time Range:"))
        
        self.time_range = QComboBox()
        self.time_range.addItems(["1 Minute", "5 Minutes", "15 Minutes", "1 Hour"])
        self.time_range.currentTextChanged.connect(self.update_graph)
        selector_layout.addWidget(self.time_range)
        
        layout.addLayout(selector_layout)
        
        # Create matplotlib figure for the graph
        self.figure = Figure(figsize=(5, 4), dpi=100)
        self.canvas = FigureCanvas(self.figure)
        layout.addWidget(self.canvas)
        
        self.ax = self.figure.add_subplot(111)
        self.initialize_graph()
    
    def initialize_graph(self):
        """Initialize the graph with empty data"""
        self.ax.clear()
        self.ax.set_title('Network Traffic')
        self.ax.set_xlabel('Time')
        self.ax.set_ylabel('Bandwidth (KB/s)')
        self.ax.grid(True)
        
        # Format x-axis as time
        self.ax.xaxis.set_major_formatter(mdates.DateFormatter('%H:%M:%S'))
        
        # Create empty lines
        self.inbound_line, = self.ax.plot([], [], 'b-', label='Inbound')
        self.outbound_line, = self.ax.plot([], [], 'r-', label='Outbound')
        self.total_line, = self.ax.plot([], [], 'g-', label='Total')
        
        self.ax.legend()
        self.canvas.draw()
    
    def update_bandwidth_graph(self):
        """Update the bandwidth usage graph"""
        self.ax.clear()
        self.ax.set_title('Network Bandwidth Usage')
        self.ax.set_xlabel('Time')
        self.ax.set_ylabel('Bandwidth (KB/s)')
        self.ax.grid(True)
        
        # Format x-axis as time
        self.ax.xaxis.set_major_formatter(mdates.DateFormatter('%H:%M:%S'))
        
        # Plot the data
        self.ax.plot(list(self.timestamps), list(self.inbound_data), 'b-', label='Inbound')
        self.ax.plot(list(self.timestamps), list(self.outbound_data), 'r-', label='Outbound')
        self.ax.plot(list(self.timestamps), list(self.total_data), 'g-', label='Total')
        
        # Set y-axis limits with some headroom
        if self.total_data:
            max_val = max(self.total_data)
            self.ax.set_ylim(0, max_val * 1.2 + 1)
        
        self.ax.legend()
        self.canvas.draw()
    
    def update_protocol_graph(self):
        """Update the protocol distribution graph"""
        self.ax.clear()
        self.ax.set_title('Protocol Distribution')
        
        # Simulated protocol data
        protocols = ['TCP', 'UDP', 'ICMP', 'HTTP', 'HTTPS', 'DNS', 'Other']
        values = [random.randint(10, 100) for _ in protocols]
        total = sum(values)
        percentages = [v / total * 100 for v in values]
        
        # Create pie chart
        self.ax.pie(percentages, labels=protocols, autopct='%1.1f%%', 
                   shadow=True, startangle=90)
        self.ax.axis('equal')  # Equal aspect ratio ensures that pie is drawn as a circle
        
        self.canvas.draw()
    
    def update_connection_graph(self):
        """Update the connection count graph"""
        self.ax.clear()
        self.ax.set_title('Active Connections')
        
        # Simulated connection data
        connection_types = ['Established', 'Time Wait', 'Close Wait', 'Listen', 'Other']
        counts = [random.randint(5, 50) for _ in connection_types]
        
        # Create bar chart
        bars = self.ax.bar(connection_types, counts)
        
        # Add value labels on top of bars
        for bar in bars:
            height = bar.get_height()
            self.ax.annotate(f'{height}',
                            xy=(bar.get_x() + bar.get_width() / 2, height),
                            xytext=(0, 3),  # 3 points vertical offset
                            textcoords="offset points",
                            ha='center', va='bottom')
        
        self.ax.set_ylabel('Connection Count')
        self.ax.grid(axis='y')
        
        self.canvas.draw()
    
    def update_graph(self):
        """Update the graph based on selected type"""
        graph_type = self.graph_type.currentText()
        
        if graph_type == "Bandwidth Usage":
            self.update_bandwidth_graph()
        elif graph_type == "Protocol Distribution":
            self.update_protocol_graph()
        else:  # Connection Count
            self.update_connection_graph()
    
    def add_data_point(self, timestamp, inbound, outbound):
        """Add a new data point to the graphs"""
        self.timestamps.append(timestamp)
        self.inbound_data.append(inbound)
        self.outbound_data.append(outbound)
        self.total_data.append(inbound + outbound)
        
        # Update the graph if showing bandwidth
        if self.graph_type.currentText() == "Bandwidth Usage":
            self.update_bandwidth_graph()

class ConnectionTableWidget(QFrame):
    """Widget displaying active network connections"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFrameShape(QFrame.StyledPanel)
        self.setFrameShadow(QFrame.Raised)
        
        self.setup_ui()
    
    def setup_ui(self):
        """Set up the user interface"""
        layout = QVBoxLayout(self)
        
        # Title
        title = QLabel("Active Connections")
        title.setStyleSheet("font-weight: bold; font-size: 14px;")
        layout.addWidget(title)
        
        # Create table for connections
        self.conn_table = QTableWidget(0, 7)
        self.conn_table.setHorizontalHeaderLabels([
            "Protocol", "Local Address", "Local Port", "Remote Address", 
            "Remote Port", "State", "Process"
        ])
        self.conn_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.conn_table.setSelectionBehavior(QTableWidget.SelectRows)
        
        layout.addWidget(self.conn_table)
    
    def add_connection(self, protocol, local_addr, local_port, remote_addr, remote_port, state, process):
        """Add a connection to the table"""
        row = self.conn_table.rowCount()
        self.conn_table.insertRow(row)
        
        self.conn_table.setItem(row, 0, QTableWidgetItem(protocol))
        self.conn_table.setItem(row, 1, QTableWidgetItem(local_addr))
        self.conn_table.setItem(row, 2, QTableWidgetItem(str(local_port)))
        self.conn_table.setItem(row, 3, QTableWidgetItem(remote_addr))
        self.conn_table.setItem(row, 4, QTableWidgetItem(str(remote_port)))
        
        state_item = QTableWidgetItem(state)
        if state == "ESTABLISHED":
            state_item.setBackground(QColor(200, 255, 200))
        elif state == "LISTEN":
            state_item.setBackground(QColor(200, 200, 255))
        elif state in ["TIME_WAIT", "CLOSE_WAIT"]:
            state_item.setBackground(QColor(255, 255, 200))
        
        self.conn_table.setItem(row, 5, state_item)
        self.conn_table.setItem(row, 6, QTableWidgetItem(process))
    
    def clear_connections(self):
        """Clear all connections from the table"""
        self.conn_table.setRowCount(0)

class ProtocolStatsWidget(QFrame):
    """Widget displaying protocol statistics"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFrameShape(QFrame.StyledPanel)
        self.setFrameShadow(QFrame.Raised)
        
        self.setup_ui()
        
        # Initialize protocol stats
        self.protocol_stats = {
            'TCP': 0,
            'UDP': 0,
            'ICMP': 0,
            'HTTP': 0,
            'HTTPS': 0,
            'DNS': 0,
            'Other': 0
        }
    
    def setup_ui(self):
        """Set up the user interface"""
        layout = QVBoxLayout(self)
        
        # Title
        title = QLabel("Protocol Statistics")
        title.setStyleSheet("font-weight: bold; font-size: 14px;")
        layout.addWidget(title)
        
        # Create table for protocol stats
        self.stats_table = QTableWidget(0, 3)
        self.stats_table.setHorizontalHeaderLabels([
            "Protocol", "Packets", "Bytes"
        ])
        self.stats_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        
        layout.addWidget(self.stats_table)
    
    def update_stats(self, protocol_stats):
        """Update protocol statistics"""
        self.stats_table.setRowCount(0)
        
        for protocol, stats in protocol_stats.items():
            row = self.stats_table.rowCount()
            self.stats_table.insertRow(row)
            
            self.stats_table.setItem(row, 0, QTableWidgetItem(protocol))
            self.stats_table.setItem(row, 1, QTableWidgetItem(str(stats.get('packets', 0))))
            
            # Format bytes in KB/MB
            bytes_val = stats.get('bytes', 0)
            if bytes_val > 1024 * 1024:
                bytes_str = f"{bytes_val / (1024 * 1024):.2f} MB"
            else:
                bytes_str = f"{bytes_val / 1024:.2f} KB"
            
            self.stats_table.setItem(row, 2, QTableWidgetItem(bytes_str))

class TrafficMonitorWidget(QWidget):
    """Main traffic monitor widget"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        
        self.setup_ui()
        
        # Timer for updating traffic data
        self.update_timer = QTimer(self)
        self.update_timer.timeout.connect(self.update_traffic_data)
        
        # Simulated traffic data
        self.inbound_rate = 0
        self.outbound_rate = 0
    
    def setup_ui(self):
        """Set up the user interface"""
        layout = QVBoxLayout(self)
        
        # Create top section with graph
        self.graph_widget = TrafficGraphWidget()
        layout.addWidget(self.graph_widget)
        
        # Create bottom section with tables
        bottom_splitter = QSplitter(Qt.Horizontal)
        
        self.conn_widget = ConnectionTableWidget()
        bottom_splitter.addWidget(self.conn_widget)
        
        self.proto_widget = ProtocolStatsWidget()
        bottom_splitter.addWidget(self.proto_widget)
        
        # Set the initial sizes of the splitter
        bottom_splitter.setSizes([500, 500])
        
        layout.addWidget(bottom_splitter)
    
    def start_monitoring(self, interface):
        """Start monitoring network traffic"""
        # Clear previous data
        self.conn_widget.clear_connections()
        
        # Reset simulated data
        self.inbound_rate = random.uniform(10, 50)
        self.outbound_rate = random.uniform(5, 30)
        
        # Start update timer
        self.update_timer.start(1000)  # Update every second
    
    def stop_monitoring(self):
        """Stop monitoring network traffic"""
        self.update_timer.stop()
    
    def update_traffic_data(self):
        """Update traffic data with simulated values"""
        # Simulate traffic rates with some randomness
        self.inbound_rate = max(0, self.inbound_rate + random.uniform(-10, 10))
        self.outbound_rate = max(0, self.outbound_rate + random.uniform(-5, 5))
        
        # Add data point to graph
        self.graph_widget.add_data_point(datetime.now(), self.inbound_rate, self.outbound_rate)
        
        # Update connection table (simulated)
        self.update_connections()
        
        # Update protocol stats (simulated)
        self.update_protocol_stats()
    
    def update_connections(self):
        """Update the connections table with simulated data"""
        # Clear existing connections
        self.conn_widget.clear_connections()
        
        # Generate random number of connections
        num_connections = random.randint(5, 15)
        
        # Common states
        states = ["ESTABLISHED", "TIME_WAIT", "CLOSE_WAIT", "LISTEN", "SYN_SENT"]
        
        # Common processes
        processes = ["chrome", "firefox", "sshd", "nginx", "apache2", "python", "systemd"]
        
        # Generate random connections
        for _ in range(num_connections):
            protocol = random.choice(["TCP", "UDP"])
            local_addr = "192.168.1." + str(random.randint(1, 254))
            local_port = random.randint(1024, 65535)
            remote_addr = ".".join([str(random.randint(1, 255)) for _ in range(4)])
            remote_port = random.choice([80, 443, 22, 25, 53, 8080, random.randint(1024, 65535)])
            state = random.choice(states)
            process = random.choice(processes)
            
            self.conn_widget.add_connection(
                protocol, local_addr, local_port, remote_addr, remote_port, state, process
            )
    
    def update_protocol_stats(self):
        """Update protocol statistics with simulated data"""
        # Generate simulated protocol stats
        protocol_stats = {
            'TCP': {
                'packets': random.randint(100, 1000),
                'bytes': random.randint(10000, 1000000)
            },
            'UDP': {
                'packets': random.randint(50, 500),
                'bytes': random.randint(5000, 500000)
            },
            'ICMP': {
                'packets': random.randint(10, 100),
                'bytes': random.randint(1000, 10000)
            },
            'HTTP': {
                'packets': random.randint(50, 300),
                'bytes': random.randint(50000, 300000)
            },
            'HTTPS': {
                'packets': random.randint(100, 600),
                'bytes': random.randint(100000, 600000)
            },
            'DNS': {
                'packets': random.randint(20, 200),
                'bytes': random.randint(2000, 20000)
            },
            'Other': {
                'packets': random.randint(10, 50),
                'bytes': random.randint(1000, 5000)
            }
        }
        
        self.proto_widget.update_stats(protocol_stats)
