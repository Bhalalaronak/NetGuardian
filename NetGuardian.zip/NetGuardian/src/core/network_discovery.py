#!/usr/bin/env python3
"""
NetGuardian - Network Discovery Module
Provides functionality for discovering devices on the network
"""

import socket
import struct
import threading
import time
import random
from datetime import datetime

class NetworkDiscovery:
    """Class for discovering devices on the network"""
    
    def __init__(self):
        self.devices = {}  # IP -> device info
        self.scanning = False
        self.scan_thread = None
    
    def start_scan(self, network_range, callback=None):
        """Start scanning the network for devices"""
        if self.scanning:
            return False
        
        self.scanning = True
        self.scan_thread = threading.Thread(
            target=self._scan_thread,
            args=(network_range, callback)
        )
        self.scan_thread.daemon = True
        self.scan_thread.start()
        
        return True
    
    def stop_scan(self):
        """Stop the network scan"""
        self.scanning = False
        if self.scan_thread:
            self.scan_thread.join(timeout=1.0)
            self.scan_thread = None
    
    def _scan_thread(self, network_range, callback):
        """Thread function for scanning the network"""
        # Parse network range (e.g., 192.168.1.0/24)
        try:
            base_ip, mask = network_range.split('/')
            mask = int(mask)
            
            # Calculate network address and broadcast address
            ip_int = self._ip_to_int(base_ip)
            network_addr = ip_int & ((1 << 32) - (1 << (32 - mask)))
            broadcast = network_addr | ((1 << (32 - mask)) - 1)
            
            # Scan all addresses in the range
            for addr in range(network_addr + 1, broadcast):
                if not self.scanning:
                    break
                
                ip = self._int_to_ip(addr)
                
                # Skip network address and broadcast address
                if addr == network_addr or addr == broadcast:
                    continue
                
                # In a real implementation, this would use ARP, ping, etc.
                # For this demo, we'll simulate discovery with random success
                if random.random() < 0.2:  # 20% chance to "find" a device
                    device_info = self._simulate_device_discovery(ip)
                    self.devices[ip] = device_info
                    
                    if callback:
                        callback(ip, device_info)
                
                # Small delay to avoid flooding the network
                time.sleep(0.01)
        
        except Exception as e:
            print(f"Error in network scan: {str(e)}")
        
        finally:
            self.scanning = False
    
    def _ip_to_int(self, ip_address):
        """Convert an IP address to an integer"""
        return struct.unpack("!I", socket.inet_aton(ip_address))[0]
    
    def _int_to_ip(self, ip_int):
        """Convert an integer to an IP address"""
        return socket.inet_ntoa(struct.pack("!I", ip_int))
    
    def _simulate_device_discovery(self, ip):
        """Simulate discovering a device (for demo purposes)"""
        # In a real implementation, this would use various techniques to
        # determine device type, hostname, MAC address, etc.
        
        # Generate a random MAC address
        mac_parts = [format(random.randint(0, 255), '02x') for _ in range(6)]
        mac = ":".join(mac_parts).upper()
        
        # Determine device type and hostname
        device_types = ["computer", "phone", "printer", "router", "switch", "server", "iot"]
        device_type = random.choice(device_types)
        
        if device_type == "computer":
            hostname = f"PC-{random.randint(1, 999)}"
            os = random.choice(["Windows 10", "Windows 11", "macOS", "Linux"])
        elif device_type == "phone":
            hostname = f"Phone-{random.randint(1, 999)}"
            os = random.choice(["Android", "iOS"])
        elif device_type == "printer":
            hostname = f"Printer-{random.randint(1, 99)}"
            os = "Embedded"
        elif device_type == "router":
            hostname = "Router"
            os = random.choice(["RouterOS", "DD-WRT", "OpenWrt"])
        elif device_type == "switch":
            hostname = f"Switch-{random.randint(1, 10)}"
            os = "Embedded"
        elif device_type == "server":
            hostname = f"Server-{random.randint(1, 10)}"
            os = random.choice(["Windows Server", "Linux", "FreeBSD"])
        else:  # IoT
            hostname = f"IoT-{random.randint(1, 50)}"
            os = "Embedded"
        
        # Return device information
        return {
            'ip': ip,
            'mac': mac,
            'hostname': hostname,
            'type': device_type,
            'os': os,
            'first_seen': datetime.now(),
            'last_seen': datetime.now(),
            'status': 'online'
        }
    
    def get_devices(self):
        """Get all discovered devices"""
        return self.devices
    
    def get_device(self, ip):
        """Get information about a specific device"""
        return self.devices.get(ip)
